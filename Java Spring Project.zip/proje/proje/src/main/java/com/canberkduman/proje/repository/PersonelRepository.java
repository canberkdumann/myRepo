package com.canberkduman.proje.repository;

import com.canberkduman.proje.model.Personel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonelRepository extends JpaRepository<Personel, Long> {

}
