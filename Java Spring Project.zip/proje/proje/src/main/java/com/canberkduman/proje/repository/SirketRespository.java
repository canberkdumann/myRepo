package com.canberkduman.proje.repository;

import com.canberkduman.proje.model.Sirket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SirketRespository extends JpaRepository<Sirket, Long> {
}
