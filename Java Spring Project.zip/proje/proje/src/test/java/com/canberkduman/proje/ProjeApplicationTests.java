package com.canberkduman.proje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjeApplicationTests {

    @Test
    void contextLoads() {
    }

}
